class VicinityOffer {
  final String name;
  final List<String> images;
  final String desc;
  final DateTime expiryAt;
  final int partnerID;
  final int creatorID;
  final List<String> products;
  final List<String> productsMRP;
  final List<String> productsOfferPrice;
  final List<String> tags;

  VicinityOffer({
    required this.name,
    this.partnerID = 0,
    required this.images,
    required this.desc,
    required this.expiryAt,
    required this.creatorID,
    this.products = const [],
    this.productsMRP = const [],
    this.productsOfferPrice = const [],
    this.tags = const [],
  });

  factory VicinityOffer.fromJson(Map<String, dynamic> json) {
    return VicinityOffer(
      name: json['name'],
      images: List<String>.from(json['images']),
      desc: json['desc'],
      expiryAt: DateTime.parse(json['expiryAt']),
      creatorID: json['creatorID'],
      products: List<String>.from(json['products']),
      partnerID: json['partnerId'],
      productsMRP: List<String>.from(json['productsMRP']),
      productsOfferPrice: List<String>.from(json['productsOfferPrice']),
      tags: List<String>.from(json['tags']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'images': images,
      'desc': desc,
      'expiryAt': expiryAt.toUtc().toIso8601String(),
      'creatorID': creatorID,
      'products': products,
      'productsMRP': productsMRP,
      'productsOfferPrice': productsOfferPrice,
      'partnerId': partnerID,
      'tags': tags,
    };
  }
}
