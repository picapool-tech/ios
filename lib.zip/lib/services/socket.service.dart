import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;

class SocketService {
  static final SocketService _instance = SocketService._internal();
  factory SocketService() => _instance;
  SocketService._internal();

  static bool isShownError = false;

  IO.Socket? socket;

  IO.Socket? createSocketConnection({
    required int userId,
    required int roomId,
    required String userName,
    required String accessToken,
    String userType = "User",
  }) {
    disconnectSocket();

    String url = "https://api.picapool.com/v2"; // Replace with your actual URL

    socket = IO.io(
      "http://api.picapool.com:3000",
      <String, dynamic>{
        'transports': ['websocket'],
        'query': {
          'roomId': "$roomId",
          'type': "User",
          'id': userId,
        },
        'extraHeaders': {
          'Authorization': 'Bearer $accessToken',
        },
        'autoConnect': false,
      },
    );

    socket!.connect();

    socket!.onConnect((_) {
      debugPrint('Connected to Socket.io Server');
      joinRoom(roomId.toString());
    });

    socket!.onReconnectAttempt((handler) {});

    socket!.onConnectError((error) {
      debugPrint('Error connecting to Socket.io Server: $error');
      
      Get.snackbar(
        'Connection Error',
        'Failed to connect to the server.',
        snackPosition: SnackPosition.TOP,
        backgroundColor: Colors.red,
        colorText: Colors.white,
      );
      return;
    });

    socket!.onError((error) {
      debugPrint("Error on socket: $error");
      Get.snackbar(
        'Connection Error',
        '$error',
        snackPosition: SnackPosition.TOP,
        backgroundColor: Colors.red,
        colorText: Colors.white,
      );
      return;
    });

    socket!.onDisconnect((_) {
      debugPrint('Disconnected from Socket.io Server');
    });

    return socket;
  }

  void joinRoom(String roomId) {
    socket?.emit('room.join', {
      'roomId': roomId,
    });
  }

  void leaveRoom(String roomId) {
    // debugPrint("Leaving room $roomId");
    socket?.emit('room.leave', {});
  }

  void sendMessage(String content, {int? replyMessageId}) {
    if (!isConnected()) {
      debugPrint('Socket is not connected, message not sent.');
      return;
    }

    final payload = {
      'content': content,
      'replyMessageId': replyMessageId,
    };

    socket!.emit('message', payload);
  }

  void sendReaction(String content, int reactionMessageId) {
    if (!isConnected()) {
      debugPrint('Socket is not connected, reaction not sent.');
      return;
    }

    final reactionData = {
      'content': content,
      'reactionMessageId': reactionMessageId,
    };

    socket!.emit('reaction', reactionData);
  }

  void kickUser(int userId) {
    if (!isConnected()) {
      debugPrint('Socket is not connected, user not kicked.');
      return;
    }

    socket!.emit('kick', {'userId': userId});
  }

  void disconnectSocket() {
    if (isConnected()) {
      // socket?.emit('room.leave', {});
      // leaveRoom();
      socket?.disconnect();
      debugPrint('Socket disconnected.');
    }
    socket?.dispose();
  }

  bool isConnected() {
    return socket?.connected ?? false;
  }
}
